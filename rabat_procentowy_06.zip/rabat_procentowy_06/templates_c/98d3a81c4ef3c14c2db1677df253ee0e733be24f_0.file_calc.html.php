<?php
/* Smarty version 5.4.2, created on 2026-03-11 12:58:07
  from 'file:C:\xampp\htdocs\php_04_uproszczony copy/app/calc.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.2',
  'unifunc' => 'content_69b158cf800c82_74973705',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '98d3a81c4ef3c14c2db1677df253ee0e733be24f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_04_uproszczony copy/app/calc.html',
      1 => 1773230272,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_69b158cf800c82_74973705 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony copy\\app';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_54757235069b158cf7c57e2_85682924', 'footer');
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_175439384569b158cf7cd1f4_12338846', 'content');
$_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../templates/main.html", $_smarty_current_dir);
}
/* {block 'footer'} */
class Block_54757235069b158cf7c57e2_85682924 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony copy\\app';
?>

Kalkulator rabatów – przykładowa treść stopki z szablonu rabatów
<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_175439384569b158cf7cd1f4_12338846 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\php_04_uproszczony copy\\app';
?>


<h2 class="content-head is-center">Kalkulator rabatów</h2>

<div class="pure-g">
<div class="l-box-lrg pure-u-1 pure-u-med-2-5">

<form action="<?php echo $_smarty_tpl->getValue('app_url');?>
/app/calc.php" method="post" class="pure-form pure-form-stacked">
	<legend>Kalkulator rabatów</legend>

	<fieldset>
		<label for="price">CENA:</label>
		<input id="price" type="text" name="price" value="<?php echo $_smarty_tpl->getValue('form')['price'];?>
" />

		<label for="rabat">RABAT: (%)</label>
		<input id="rabat" type="text" name="rabat" value="<?php echo $_smarty_tpl->getValue('form')['rabat'];?>
" />

		<button type="submit" class="pure-button">Oblicz</button>
	</fieldset>
</form>

</div>

<div class="l-box-lrg pure-u-1 pure-u-med-3-5">

<div class="messages">

<?php if ((null !== ($_smarty_tpl->getValue('messages') ?? null))) {?>
	<?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('messages')) > 0) {?>
	<h4>Wystąpiły błędy:</h4>
	<ol class="err">
	<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('messages'), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
		<li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
	<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
	</ol>
	<?php }
}?>

<?php if ((null !== ($_smarty_tpl->getValue('infos') ?? null))) {?>
	<?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('infos')) > 0) {?>
	<h4>Informacje:</h4>
	<ol class="inf">
	<?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('infos'), 'msg');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach1DoElse = false;
?>
		<li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
	<?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
	</ol>
	<?php }
}?>

<?php if ((null !== ($_smarty_tpl->getValue('result') ?? null))) {?>
	<h4>Wynik</h4>
	<p class="res">
	<?php echo $_smarty_tpl->getValue('result');?>

	</p>
<?php }?>

</div>

</div>
</div>

<?php
}
}
/* {/block 'content'} */
}
