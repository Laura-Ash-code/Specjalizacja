<?php
// KONTROLER kalkulatora rabatów
require_once dirname(__FILE__).'/../config.php';

// załaduj Smarty
require_once _ROOT_PATH.'/lib/smarty/libs/Smarty.class.php';

use Smarty\Smarty;

// pobranie parametrów
function getParams(&$form){
	$form['price'] = isset($_REQUEST['price']) ? $_REQUEST['price'] : null;
	$form['rabat'] = isset($_REQUEST['rabat']) ? $_REQUEST['rabat'] : null;
}

// walidacja parametrów
function validate(&$form,&$infos,&$msgs,&$hide_intro){

	if ( ! (isset($form['price']) && isset($form['rabat'])) ) return false;

	$hide_intro = true;

	$infos [] = 'Przekazano parametry.';

	if ($form['price'] == "") $msgs [] = 'Podaj cenę';
	if ($form['rabat'] == "") $msgs [] = 'Podaj rabat';

	if (count($msgs)==0){
		if (!is_numeric($form['price'])) $msgs [] = 'Cena musi być liczbą';
		if (!is_numeric($form['rabat'])) $msgs [] = 'Rabat musi być liczbą';
	}

	if (count($msgs)>0) return false;
	else return true;
}

// wykonanie obliczeń
function process(&$form,&$infos,&$msgs,&$result){

	$infos [] = 'Parametry poprawne. Wykonuję obliczenia.';

	$form['price'] = floatval($form['price']);
	$form['rabat'] = floatval($form['rabat']);

	if ($form['rabat'] < 0 || $form['rabat'] > 100){
		$msgs [] = 'Rabat musi być w zakresie 0–100%';
		return;
	}

	$result = $form['price'] - ($form['price'] * $form['rabat'] / 100);
}


// inicjacja zmiennych
$form = null;
$infos = array();
$messages = array();
$result = null;

// pobranie danych
getParams($form);

// walidacja + obliczenia
if ( validate($form,$infos,$messages,$hide_intro) ){
	process($form,$infos,$messages,$result);
}

// przygotowanie Smarty
$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);

$smarty->assign('page_title','Kalkulator rabatów');
$smarty->assign('page_description','Kalkulator do obliczania ceny po rabacie');
$smarty->assign('page_header','Kalkulator rabatów');
$smarty->assign('page_footer','Jak nie działa to nie nasza wina <br> Strona tylko dla mądrych użytkowników');

// dane dla widoku
$smarty->assign('form',$form);
$smarty->assign('result',$result);
$smarty->assign('messages',$messages);
$smarty->assign('infos',$infos);

// wyświetlenie szablonu
$smarty->display(_ROOT_PATH.'/app/rabat.html');